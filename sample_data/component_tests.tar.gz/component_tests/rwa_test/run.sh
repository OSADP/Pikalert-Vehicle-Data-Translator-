#!/bin/bash

set -x

./rwa -s segment_statistics.20141201.2350.nc -l log/rwa_mi -t merge_rec_tmt.20141201.2343.nc 20141201.2350 mi_rwa.cfg MI_logicast_road_sites.asc mi_rwh.20141201.2350.nc output/district_alerts.20141201.2350.json output/plot_data.20141201.2350 output/obs_stats_data.20141201.2350.json output/maw.20141201.2350.json

