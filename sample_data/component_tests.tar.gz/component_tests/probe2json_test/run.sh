#!/bin/bash

set -x

./probe_to_json -l log/probe_to_json_mi 201412012350 mi_cdf_config.cfg vdt.20141201.2350.nc output/vdt.20141201.2350.json
