#!/bin/bash

set -x

./rwh rwh_config.cfg 201412020000 201412050000 MI_logicast_road_sites.asc mi_roads.20140613.nc output/mi_rwh.20141201.2350.nc -l log/run_rwh_mi -d 1 -w rdwx_fcst.20141201.2330.nc -r merge_rec_tmt.20141201.2343.nc -s segment_statistics.20141201.2350.nc
